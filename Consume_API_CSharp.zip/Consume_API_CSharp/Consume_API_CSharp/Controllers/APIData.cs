﻿using Microsoft.AspNetCore.Mvc;
using Consume_API_CSharp.Models;
namespace Consume_API_CSharp.Controllers
{
    public class APIData : Controller
    {
        public IActionResult Comments()
        {
            CommentsData data = new CommentsData();
            ViewBag.Comments = data.GetComments();
            return View();
        }
    }
}
