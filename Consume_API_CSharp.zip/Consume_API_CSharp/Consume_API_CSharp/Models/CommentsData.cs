﻿using System.Net.Http.Formatting;
namespace Consume_API_CSharp.Models
{
    public class CommentsData
    {
        public int postId { get; set; }
        public int id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string body { get; set; }




        List<CommentsData> cList = new List<CommentsData>();

        public List<CommentsData> GetComments()
        {
            string url = "https://jsonplaceholder.typicode.com/comments";
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            var callService = client.GetAsync(url);
            var response = callService.Result;
            //if we get a success, we will start reading the data
            if (response.IsSuccessStatusCode)
            {
                var read = response.Content.ReadAsAsync<List<CommentsData>>();

                read.Wait();
                cList = read.Result;
               
            }
            return cList;
        }
    }
}
