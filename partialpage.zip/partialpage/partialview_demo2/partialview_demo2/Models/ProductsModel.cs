﻿namespace partialview_demo2.Models
{
    public class ProductsModel
    {
        public int pId { get; set; }
        public string pName { get; set; }
        public int pPrice { get; set; }
        public int pAvailableQty { get; set; }
        public bool pIsInstock { get; set; }
        public string pCategory { get; set; }

        static List<ProductsModel> pList = new List<ProductsModel>()
        {
            new ProductsModel(){ pId=101, pName="Pepsi", pCategory="Cold-Drinks", pAvailableQty=10, pIsInstock=true, pPrice=50},
            new ProductsModel(){ pId=102, pName="Fossil", pCategory="Electronic", pAvailableQty=10, pIsInstock=true, pPrice=50},
            new ProductsModel(){ pId=103, pName="Maggie", pCategory="Fast-Food", pAvailableQty=10, pIsInstock=true, pPrice=50},
            new ProductsModel(){ pId=104, pName="Dell", pCategory="Electronic", pAvailableQty=10, pIsInstock=true, pPrice=50},
            new ProductsModel(){ pId=105, pName="Airpods", pCategory="Electronic", pAvailableQty=10, pIsInstock=true, pPrice=50},
            new ProductsModel(){ pId=106, pName="LG", pCategory="Electronic", pAvailableQty=10, pIsInstock=true, pPrice=50},
            new ProductsModel(){ pId=107, pName="OGeneral", pCategory="Electronic", pAvailableQty=10, pIsInstock=true, pPrice=50},
            new ProductsModel(){ pId=108, pName="Pasta", pCategory="Fast-Food", pAvailableQty=10, pIsInstock=true, pPrice=50},
            new ProductsModel(){ pId=109, pName="Louie Phillip", pCategory="Clothing", pAvailableQty=10, pIsInstock=true, pPrice=50},
            new ProductsModel(){ pId=110, pName="Nike", pCategory="Clothing", pAvailableQty=10, pIsInstock=true, pPrice=50},
        };


        public List<ProductsModel> GetColdDrinks()
        {
            var colddrinks = from p in pList
                             where p.pCategory == "Cold-Drinks"
                             select p;

            return colddrinks.ToList();
        }

        public List<ProductsModel> GetElectronics()
        {
            var electronics = from p in pList
                              where p.pCategory == "Electronic"
                              select p;

            return electronics.ToList();
        }


        public List<ProductsModel> GetClothing()
        {
            var clothing = from p in pList
                           where p.pCategory == "Clothing"
                           select p;

            return clothing.ToList();
        }
    }
}
