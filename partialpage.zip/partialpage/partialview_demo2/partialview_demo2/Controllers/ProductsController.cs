﻿using Microsoft.AspNetCore.Mvc;
using partialview_demo2.Models;
namespace partialview_demo2.Controllers
{
    public class ProductsController : Controller
    {
        ProductsModel _model = new ProductsModel();
        public IActionResult Electronics()
        {
            ViewData["products"] = _model.GetElectronics();
            return View();
        }

        public IActionResult Colddrinks()
        {
            ViewData["products"] = _model.GetColdDrinks();
            return View();
        }

        public IActionResult Clothing()
        {
            ViewData["products"] = _model.GetClothing();
            return View();
        }
    }
}
