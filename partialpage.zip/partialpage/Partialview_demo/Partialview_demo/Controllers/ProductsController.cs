﻿using Microsoft.AspNetCore.Mvc;
using Partialview_demo.Models;
namespace Partialview_demo.Controllers
{
    public class ProductsController : Controller
    {
        ProductsModel _model= new ProductsModel();
        public IActionResult Electronics()
        {
            ViewBag.electonics = _model.GetElectronics();
            return View();
        }

        public IActionResult Colddrinks()
        {
            ViewBag.colddrinks = _model.GetColdDrinks();
            return View();
        }

        public IActionResult Clothing()
        {
            ViewBag.clothing = _model.GetClothing();
            return View();
        }
    }
}
