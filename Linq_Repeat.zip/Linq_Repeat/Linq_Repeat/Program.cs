﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq_Repeat
{
    internal class Program
    {
        static void Main(string[] args)
        {
            shoppingDBEntities db = new shoppingDBEntities();                 

            bool continueOperation = false;

            Console.WriteLine("Welcome to Banking");
            Console.WriteLine("Enter User Name");
            string uName = Console.ReadLine();
            Console.WriteLine("Enter Password");
            string pwd = Console.ReadLine();

            var loginResult = (from l in db.Logins
                              where l.userName == uName && l.password == pwd    
                              select l).Count();

            if (loginResult == 1)
            {
                continueOperation = true;
            }
            else
            {
                Console.WriteLine("Invalid Credentials, please try again");
            }



            while (continueOperation)
            {
                #region Display Menu
                Console.Clear();
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~ Welcome to Banking ~~~~~~~~~~~~~~~~~~~~~~~~~");
                Console.WriteLine("1. Create New Employee");
                Console.WriteLine("2. Check Employee Details");
                Console.WriteLine("3. Get Employee List");
                Console.WriteLine("4. Delete Employee");
                Console.WriteLine("5. Update Employee");
                Console.WriteLine("6. Exit");
                #endregion

                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    #region Case 1 Add New Employee
                    case 1:  
                        EmployeeInfo newEmp = new EmployeeInfo();
                        Console.WriteLine("Enter Employee Number");
                        newEmp.empNo = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Employee Name");
                        newEmp.empName = Convert.ToString(Console.ReadLine());
                        Console.WriteLine("Enter Employee Designation");
                        newEmp.empDesignation = Convert.ToString(Console.ReadLine());
                        Console.WriteLine("Enter Employee Salary");
                        newEmp.empSalary = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Employee Department");
                        newEmp.empDept = Convert.ToInt32(Console.ReadLine());

                        db.EmployeeInfoes.Add(newEmp); //add the emp in my memory
                        db.SaveChanges(); //commit to database
                        Console.WriteLine("Employee Added Successfully");
                        Console.ReadLine();                  
                        break;
                    #endregion

                    #region Case 3 : Check Employee Details
                    case 2:
                        Console.WriteLine("Enter Employee Number");

                        int empNo = Convert.ToInt32(Console.ReadLine());
                        var emp = (from e in db.EmployeeInfoes
                                  where e.empNo == empNo    
                                  select e).SingleOrDefault();
                        if (emp!=null)
                        {
                            Console.WriteLine("Emp No " + emp.empNo);
                            Console.WriteLine("Emp No " + emp.empName);
                            Console.WriteLine("Emp No " + emp.empDesignation);
                            Console.WriteLine("Emp No " + emp.empSalary);
                            Console.WriteLine("Emp No " + emp.empDept);
                        }
                        else
                        {
                            Console.WriteLine("Employee Not Found");
                        }
                        Console.ReadLine();

                        break;
                    #endregion

                    #region Case 3: Employee List
                    case 3:
                        var empList = from e in db.EmployeeInfoes
                                      join d in db.deptInfoes
                                      on e.empDept equals d.dNo
                                      select new
                                      {
                                          Number = e.empNo,
                                          Name = e.empName,
                                          WorksAs = e.empDesignation,
                                          CTC = e.empSalary * 12,
                                          Department = d.dName,
                                          Location = d.dLocation
                                      };
                        foreach (var item in empList)
                        {
                            Console.WriteLine("Employee Number " + item.Number);
                            Console.WriteLine("Employee Name " + item.Number);
                            Console.WriteLine("Employee Designation " + item.Number);
                            Console.WriteLine("Annual Pay " + item.Number);
                            Console.WriteLine("Employee Departmernt " + item.Number);
                            Console.WriteLine("Location " + item.Number);
                            Console.WriteLine("------------------------------------------------------");
                        }
                        break;
                    #endregion

                    #region Case 4:  Delete Employee
                    case 4:
                        Console.WriteLine("Enter Employee Number");

                        int empNoToDelete = Convert.ToInt32(Console.ReadLine());
                        var empToDelete = (from e in db.EmployeeInfoes
                                   where e.empNo == empNoToDelete
                                   select e).SingleOrDefault();
                        if (empToDelete != null)
                        {
                            db.EmployeeInfoes.Remove(empToDelete);
                            db.SaveChanges();
                            Console.WriteLine("Emplotee Deleted From System");
                        }
                        else
                        {
                            Console.WriteLine("Employee Not Found");
                        }
                        break;
                    #endregion

                    #region Case 5 : Update Employee
                    case 5:
                        int empNoToUpdate = Convert.ToInt32(Console.ReadLine());
                        var empToUpdate = (from e in db.EmployeeInfoes
                                           where e.empNo == empNoToUpdate
                                           select e).SingleOrDefault();
                        if (empToUpdate != null)
                        {
                            Console.WriteLine("Enter New Name");
                            empToUpdate.empName = Console.ReadLine();
                            Console.WriteLine("Enter New Salary ");
                            empToUpdate.empSalary = Convert.ToInt32(Console.ReadLine());

                            db.SaveChanges();
                            Console.WriteLine("Employee Updated Successfully");
                         }
                        else
                        {
                            Console.WriteLine("Employee Not Found");
                        }
                            break;
                    #endregion

                    #region Case 6: Exit
                    case 6:
                        continueOperation = false;
                        Console.WriteLine("Thank You For Banking with Us");
                        break;
                    #endregion

                    #region Default - Print Invalid Option choosen
                    default:
                        Console.WriteLine("Invalid Option");
                        break;
                        #endregion
                }

            }

        }
    }
}
